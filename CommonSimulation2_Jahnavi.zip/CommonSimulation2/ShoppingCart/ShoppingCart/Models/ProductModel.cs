﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShoppingCart.Models
{
    public class ProductModel
    {
        public long ProdId { get; set; }
        

        public string ProdName { get; set; }
        public decimal TotalAmtPayable { get; set; }
        public string PaymentMode { get; set; }
    }
}