﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShoppingCart.Models
{
    public class OrderDetailsModel
    {
        public int CustId { get; set; }
        public long ProdId { get; set; }
        public long OrderId { get; set; }
        public DateTime OrderDate { get; set; }

        public int Qty { get; set; }

        public string PaymentMode{ get; set; }
        public decimal TotalAmountPayable { get; set; }
    }
}