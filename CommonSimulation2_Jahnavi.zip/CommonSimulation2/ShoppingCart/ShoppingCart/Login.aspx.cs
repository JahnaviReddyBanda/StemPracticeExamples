﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ShoppingCart.DataAccessLayer;

namespace ShoppingCart
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                ShoppingCartDB db = new ShoppingCartDB();
                var res = db.Login(int.Parse(txtcid.Text), txtpwd.Text);
                Output.Text = res;
                if (res == "Success")
                {
                    Session["cid"] =long.Parse(txtcid.Text);
                    //FormsAuthentication.RedirectFromLoginPage(txtcid.Text, false);
                    Response.Redirect("Home.aspx");


                }

            }
            catch (Exception ex)
            {
                Output.Text = ex.Message;
            }
        }
    }
}