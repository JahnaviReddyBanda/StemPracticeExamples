﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ShoppingCart.DataAccessLayer;
using ShoppingCart.Models;

namespace ShoppingCart
{
    public partial class NewCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                ShoppingCartDB db = new ShoppingCartDB();
                CustomerModel cm = new CustomerModel();
                cm.CustName = txtname.Text;
                cm.CustAddress = txtadd.Text;
                cm.MobNo = long.Parse(txtmobno.Text);
                cm.Email = txtemail.Text;
                foreach (ListItem li in rbgender.Items)
                {
                    if (li.Selected)
                        cm.Gender = li.Text;
                }
                
                cm.Password = txtpwd.Text;
                var res = db.InsertCustomer(cm);
                if (res > 0)
                    Output.Text = "New CustomerID is :" + res;
            }
            catch (Exception ex)
            {
                Output.Text = ex.Message;
            }
        }
    }
}