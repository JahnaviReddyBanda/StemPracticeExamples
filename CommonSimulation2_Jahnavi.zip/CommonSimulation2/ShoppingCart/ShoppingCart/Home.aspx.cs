﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ShoppingCart.DataAccessLayer;
using ShoppingCart.Models;
using System.Security;

namespace ShoppingCart
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (Session["cid"] == null)
                Response.Redirect("Login.aspx");
            else
                txtcid.Text = Session["cid"].ToString();


        }

        protected void btnOrder_Click(object sender, EventArgs e)
        {
            if (int.Parse(txtqty.Text) > int.Parse(txtstock.Text))
            {
                Output.Text = "stock not available";
                return;
            }
            try
            {
                
                
                    OrderDetailsModel om = new OrderDetailsModel();
                    om.CustId = int.Parse(txtcid.Text);
                    om.Qty = int.Parse(txtqty.Text);
                    txtpid.Text = Session["prodid"].ToString();
                    foreach (ListItem li in rbpaymode.Items)
                    {
                        if (li.Selected)
                            om.PaymentMode = li.Text;
                    }
                    decimal totalamt = om.Qty * decimal.Parse(Session["prodprice"].ToString());

                    txtTamt.Text = totalamt.ToString();
                    ShoppingCartDB db = new ShoppingCartDB();
                    var res = db.InsertOrder(om);

                    Output.Text = res;
                    GridView1.DataBind();
                
                
            }
            catch (Exception ex)
            {
                Output.Text = ex.Message;
            }


            
        }
        protected void btn1_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            Session["prodprice"] = row.Cells[2].Text;
            txtprice.Text = Session["prodprice"].ToString();
            txtstock.Text = row.Cells[3].Text;



        }

        
    }
}
