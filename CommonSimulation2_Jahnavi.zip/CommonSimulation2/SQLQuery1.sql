﻿use CommonSimulation2

create table Customer
(CustId int constraint pk_custid primary key identity(1000,99999),
CustName varchar(30) not null,
CustAddress varchar(100) not null,
MobNo bigint constraint un_mobno unique,
EmailId varchar(100) constraint un_email unique,
Gender varchar(10) not null)

Select * from Customer

alter table Customer
add Password varchar(30) not null

create table Product
(ProdId bigint constraint pk_pid primary key identity(1661100,1),
ProdName varchar(30) not null,
ProdPrice money not null,
Stock int)

create table OrderDetails
(OrderId int constraint pk_oid primary key identity,
OrderDate datetime constraint def_Od default getdate(),
CustId int constraint fk_cust_order references Customer(CustId),
ProdId bigint constraint fk_prod_order references Product(ProdId),
Qty int not null,
TotalAmountPayable money not null,
PaymentMode varchar(10) not null)

Select * from OrderDetails

create procedure sp_InsertCustomer
(@name varchar(30),@add varchar(100),@mno bigint,@email varchar(50),
@gen varchar(10),@pwd varchar(30),@cid int out)
as
begin
insert into Customer values(@name,@add,@mno,@email,@gen,@pwd)
select @cid=@@IDENTITY
end

--- login customer
create proc sp_LoginCustomer(@cid int,@pass varchar(30))
as
begin
select * from Customer where CustId=@cid and Password=@pass
end


--insert order
create proc sp_InsertOrder(@cid int,@pid bigint,@qty int,@tamt money,@paymode varchar(10),@oid int out)
as
begin
insert into [OrderDetails](CustId,ProdId,Qty,TotalAmountPayable,PaymentMode) values(@cid,@pid,@qty,@tamt,@paymode)
select @oid=@@IDENTITY
end

alter proc sp_InsertOrder(@cid int,@pid bigint,@qty int,@tamt money,@paymode varchar(10),@oid int out)
as
begin
insert into [OrderDetails](CustId,ProdId,Qty,TotalAmountPayable,PaymentMode) values(@cid,@pid,@qty,@tamt,@paymode)
update Product set Stock=Stock-@qty where ProdId=@pid and Stock>@qty
select @oid=@@IDENTITY
end

select * from product

insert into Product values('chocolate',35,20)
insert into Product values('cookies',60,20)
insert into Product values('chocolate icecream',155,10)
insert into Product values('Soft Drink',30,10)