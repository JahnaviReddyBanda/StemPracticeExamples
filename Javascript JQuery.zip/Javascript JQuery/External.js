var name=prompt("Enter Username");
var age=prompt("Enter age");
alert("Name:"+name);
alert("age:"+age);