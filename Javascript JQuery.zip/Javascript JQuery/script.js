const calc= () => {

    let marketing = document.querySelector("#marketing").value;
    
    let accounting= document.querySelector("#accounting").value;
    
    let computing= document.querySelector("#computing").value;
   
    let grades = "";
    
    let totalgrades = parseFloat(marketing) +parseFloat(computing) + parseFloat(accounting) ;
    
    let avg = (totalgrades / 4) ;
    
    if (avg <= 100 && avg >= 80) {
    
                   grades = "A";
    
    } else if (avg <= 79 && avg >= 60) {
    
                   grades = "B";
    
    } else if (avg <= 59 && avg >= 40) {
    
                   grades = "C";
    
    } else {
    
                   grades = "F";
    
    }
    
     
    
    if (marketing == "" || accounting == "" || computing == "" )
     {
    
                   document.querySelector("#showdata").innerHTML = "Please enter all the fields";
    
    } else {
    
            if (percentage >= 39.5) {
    
                   document.querySelector(  "#showdata" ).innerHTML =
                  ` Out of 400 your total is ${totalgrades}   and percentage is ${percentage}%. <br>
    
                    Your grade is ${grades}. You are Pass. `;
    
                   } else {
    
                   document.querySelector(
    
                                  "#showdata"
    
                   ).innerHTML =
    
                                  ` Out of 400 your total is ${totalgrades}
    
                                  and percentage is ${percentage}%. <br>
    
                                  Your grade is ${grades}. You are Fail. `;
    
                   }
    
    }
    
    };
    
    