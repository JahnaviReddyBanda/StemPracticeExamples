﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DessertShop
{
    class IceCream:DessertItem
    {
        int numberOfScoops;
        double pricePerScoop;
        double toppingPrice;
        public override double getCost()
        {
            double cost = (numberOfScoops * pricePerScoop)+ toppingPrice;
            return (cost);
        }
        public override string ToString()
        {
            return getCost().ToString() + "cents";
        }
        public IceCream(string name, int numberOfScoops, double pricePerScoop, double toppingPrice) : base(name)
        {
            this.numberOfScoops = numberOfScoops;
            this.pricePerScoop = pricePerScoop;
            this.toppingPrice = toppingPrice;

        }
    }
}
