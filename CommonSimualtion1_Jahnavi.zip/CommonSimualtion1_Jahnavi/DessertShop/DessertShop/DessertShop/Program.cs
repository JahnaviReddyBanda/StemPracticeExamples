﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DessertShop
{
    class Program
    {
        static void Main(string[] args)
        {
            Candy candy1 = new Candy("fudge",2.30,0.89);
            candy1.getName();
            candy1.setName();
            Console.WriteLine(candy1.ToString());

            Cookie cookie1 = new Cookie("chocolate cookie", 4, 399);
            cookie1.getName();
            cookie1.setName();
            Console.WriteLine(cookie1.ToString());

            IceCream icecream1 = new IceCream("chocolate", 2, 60,50);
            icecream1.getName();
            icecream1.setName();
            Console.WriteLine(icecream1.ToString());
        }
    }
}
