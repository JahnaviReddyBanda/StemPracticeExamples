﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DessertShop
{
    public abstract class DessertItem
    {
        string dessertname;
        public DessertItem(string dessertname)
        {
            this.dessertname = dessertname;
        }
        public DessertItem()
        { }
        public void getName()
        {
            Console.WriteLine("Enter name:");
            dessertname = Console.ReadLine();
        }
        public void setName()
        {
            Console.WriteLine(dessertname);

        }
        public abstract double getCost();
    }
}
