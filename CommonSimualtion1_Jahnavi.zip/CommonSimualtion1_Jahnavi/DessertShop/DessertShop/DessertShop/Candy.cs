﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DessertShop
{
    class Candy : DessertItem
    {
        double weight;
        double pricePerPound;

        public override double getCost()
        {
            double cost = weight * pricePerPound;
            return (cost);
        }
        public override string ToString()
        {
            return getCost().ToString()+"cents";
        }
        public Candy(string name,double weight,double pricePerPound) : base(name)
        {
            this.weight = weight;
            this.pricePerPound = pricePerPound;
        }


    }
}
