﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DessertShop
{
    class Cookie : DessertItem
    {
        int itemCount;
        double pricePerDozen;
        public override double getCost()
        {
            double cost = itemCount * (pricePerDozen/12);
            return (cost);
        }
        public override string ToString()
        {
            return getCost().ToString() + "cents";
        }
        public Cookie(string name, int itemCount, double pricePerDozen) : base(name)
        {
            this.itemCount = itemCount;
            this.pricePerDozen = pricePerDozen;
        }
    }
}
