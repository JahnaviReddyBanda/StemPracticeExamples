﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using ShoppingCart.Models;

namespace ShoppingCart.DataAccessLayer
{
    public class ShoppingDB
    {
        string connect = "Data Source=(localdb)\\MSSqlLocalDB;Initial Catalog=CommonSimulation2;Integrated Security=true;";
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader r = null;
        public string Login(int cid, string password)
        {
            try
            {
                con = new SqlConnection(connect);
                con.Open();
                cmd = new SqlCommand("sp_LoginCustomer", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@cid", cid);
                cmd.Parameters.AddWithValue("@pass", password);
                r = cmd.ExecuteReader();
                string res = "";
                if (r.Read())
                    res = "Success";
                else
                    res = "Invalid Credentials";
                return res;
            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return "";
        }
        public int InsertCustomer(CustomerModel cm)
        {
            try
            {
                con = new SqlConnection(connect);
                con.Open();
                cmd = new SqlCommand("sp_InsertCustomer", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", cm.CustName);
                cmd.Parameters.AddWithValue("@add", cm.CustAddress);
                cmd.Parameters.AddWithValue("@mno", cm.MobNo);
                cmd.Parameters.AddWithValue("@email", cm.Email);
                cmd.Parameters.AddWithValue("@gen", cm.Gender);
                cmd.Parameters.AddWithValue("@pwd", cm.Password);
                SqlParameter cid = new SqlParameter("@cid", SqlDbType.Int);
                cid.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(cid);
                var res = cmd.ExecuteNonQuery();
                if (res == 1)
                    return (int)cid.Value;
            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return 0;
            
        }

        public int CheckQuantity(int pid)
        {
            try
            {
                con = new SqlConnection(connect);
                con.Open();
                cmd = new SqlCommand("sp_CheckQuantity", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pid", pid);
                r = cmd.ExecuteReader();
                int res=0;
                if (r.Read())
                    res = int.Parse(r[0].ToString());
                return res;
            }
            catch 
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            
        }

        public string InsertOrder(OrdersModel om)
        {
            try
            {
                con = new SqlConnection(connect);
                con.Open();
                cmd = new SqlCommand("sp_InsertOrder", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@custid", om.CustId);
                cmd.Parameters.AddWithValue("@prodid", om.ProductId);
                cmd.Parameters.AddWithValue("@qty", om.Quantity);
                cmd.Parameters.AddWithValue("@total", om.Total);
                cmd.Parameters.AddWithValue("@mode", om.Payment);
                SqlParameter oid = new SqlParameter("@oid", SqlDbType.Int);
                oid.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(oid);
                var res = cmd.ExecuteNonQuery();
                if (res > 0)
                    return "Order is Succesfully Added. The Order Id is: " + oid.Value;
            }
            catch
            {

                throw;
            }
            finally
            {
                con.Close();
            }
            return "";
        }


    }
}