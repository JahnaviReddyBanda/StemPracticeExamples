﻿using ShoppingCart.DataAccessLayer;
using ShoppingCart.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShoppingCart
{
    public partial class NewCustomer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                ShoppingDB db = new ShoppingDB();
                CustomerModel m = new CustomerModel();
                m.CustName = txtName.Text;
                m.CustAddress = txtAddress.Text;
                m.MobNo = long.Parse(txtPhone.Text);
                if (rbMale.Checked)
                    m.Gender = rbMale.Text;
                if (rbFemale.Checked)
                    m.Gender = rbFemale.Text;
                m.Password = txtPass.Text;
                m.Email = txtEmail.Text;
                var res = db.InsertCustomer(m);
                if (res > 0)
                    output.Text = "New Customer ID is:" + res;
            }
            catch (Exception ex)
            {

                output.Text = ex.Message;
            }
        }


    }
}