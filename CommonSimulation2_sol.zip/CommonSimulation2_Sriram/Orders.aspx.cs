﻿using ShoppingCart.DataAccessLayer;
using ShoppingCart.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShoppingCart
{
    public partial class Orders : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["cid"] == null)
                Response.Redirect("login.aspx");
            else
                txtcid.Text = Session["cid"].ToString();
        }

        protected void btn1_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            Session["pid"] = row.Cells[0].Text;
            Session["price"] = row.Cells[2].Text;
            //Response.Write("Product Id: " + Session["pid"]+" "+ Session["price"]);
            txtpid.Text = Session["pid"].ToString();
        }

        protected void btnOrder_Click(object sender, EventArgs e)
        {
            try
            {
                ShoppingDB db = new ShoppingDB();
                int res = db.CheckQuantity(int.Parse(txtpid.Text));
                if(res>=int.Parse(txtQty.Text))
                {
                    OrdersModel model = new OrdersModel();
                    model.CustId = int.Parse(txtcid.Text);
                    model.ProductId = int.Parse(txtpid.Text);
                    model.Quantity = int.Parse(txtQty.Text);
                    decimal total = model.Quantity * decimal.Parse(Session["price"].ToString());
                    txtTotal.Text = total.ToString();
                    model.Total = total;
                    if (rbCard.Checked)
                        model.Payment = rbCard.Text;
                    if (rbCash.Checked)
                        model.Payment = rbCash.Text;
                    string val = db.InsertOrder(model);
                    output.Text = val;
                    GridView1.DataBind();
                    txtQty.Text = "";

                }
                else
                {
                    output.Text = "Quantity must be less than stocks available.";
                }

            }
            catch (Exception ex)
            {

                output.Text = ex.Message;
            }
        }
    }
}