﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShoppingCart.Models
{
    public class OrdersModel
    {
        public int OrderId { get; set; }
        public int CustId { get; set; }
        public int ProductId { get; set; }
        public DateTime OrderDate { get; set; }
        public int Quantity { get; set; }
        public decimal Total { get; set; }
        public string Payment { get; set; }

    }
}