use stemDB
--ddl with constraints
--using create and alter table
--create table 
create table emp
(empid int,
name varchar(30))


--change table name
sp_rename'dbo.emp','EmployeeDetails'

--change column name
sp_rename'dbo.EmployeeDetails.name','empname'

--change datatype of column
alter table EmployeeDetails
alter column empid bigint

--add a column
alter table EmployeeDetails
add dept varchar(30),
desg varchar(50),
salary money,
doj datetime


--drop column
alter table EmployeeDetails
drop column doj,dept

--drop table
drop table EmployeeDetails

create table Employee
(EmpID int constraint pk_empid primary key identity,
Empname varchar(30) not null,
Dept varchar(30) constraint chk_dept check(dept in('IT','ACCOUNTS','HR','ADMIN')),
EmailId varchar(30) constraint un_email unique,
Location varchar(30)constraint un_loc default'HYDERABAD',
Salary money constraint chk_salary check( salary between 10000 and 99999),
Desg varchar(30),
Skillsets varchar(100)
)

create table Project
(Projid int constraint pk_projid primary key identity(100,100),
Projname varchar(30) not null)

alter table Employee
add Projid int constraint fk_emp_proj references Project(Projid)

--DML Commands insert update delete,truncate
--insert multiple values in one single insert query
insert into Project values('ICICI Bank'),('Amazon'),('Flipkart')

--insert data for all columns
--donot insert values for identity column
insert into Employee values('Martin','IT','martin@gmail.com','Gurgaon','75000','programmer','HTML,C#',300)

--insert data only into specific not null columns
--primary key,check,not null
insert into Employee(Empname,Dept,Salary)values('ALEX','ACCOUNTS','65000')

insert into Employee(Empname,Dept,Salary,EmailId)values('CLARK','HR','65000','clark@gmail.com')

--insert specifically null values
--null value should not be in "
insert into Employee values('Scott','Admin','scott@gmail.com','Bangalore',55000,NULL,null,100)

--update data
update Employee set Projid=200 where Projid=null
--whenever we check null values = operator will not work,replace = with is
--it is applicable for select update delete

update Employee set Projid=200 where Projid is null

 update Employee set Salary=Salary+107.99

 delete from Employee where EmailId is null

 truncate table Employee 


 create table [dept](
 [deptno][int] constraint [pk_dpt] primary key,
 [dname] [varchar](20),
 [loc] [varchar](20))

insert dept values(10,'ACCOUNTING','NEWYORK')
insert dept values(20,'RESEARCH','DALLAS')
insert dept values(30,'SALES','CHICKAGO')
insert dept values(40,'OPERATIONS','BOSTON')

create table emp(EMPNO int constraint pk_emp primary key,
ENAME varchar(10),JOB varchar(9),MGR int, HIREDATE DATEtime,
SAL money,COMM money,
DEPTNO int constraint fk_dep foreign key references dept(deptno))

insert emp values (7369,'SMITH','CLERK',7902,'DEC 17 1980',800,NULL,20)
INSERT EMP VALUES(7499,'ALLEN','SALESMAN',7698,'FEB 20 1981',1600,300,30)
INSERT EMP VALUES(7521,'WARD','SALESMAN',7698,'FEB 22 1981',1250,500,30)
INSERT EMP VALUES(7566,'JONES','MANAGER',7839,'APR 02 1981',2975,NULL,20)
INSERT EMP VALUES(7654,'MARTIN','SALESMAN',7698,'SEP 28 1981',1250,1400,30)
INSERT EMP VALUES(7698,'BLAKE','MANAGER',7839,'MAY 01 1981',2850,NULL,30)
INSERT EMP VALUES(7782, 'CLARK','MANAGER',7839,'JUN 09 1981',2450,NULL,10)
INSERT EMP VALUES(7788, 'SCOTT','ANALYST', 7566,'APR 19 1987',3000,NULL,20)
INSERT EMP VALUES(7839, 'KING','PRESIDENT',NULL,'NOV 17 1981',5000,NULL,10)
INSERT EMP VALUES(7844, 'TURNER','SALESMAN',7698, 'SEP 08 1981',1500,NULL,30)
INSERT EMP VALUES(7876, 'ADAMS','CLERK', 7788, 'MAY 23 1987',1100,NULL,20)
INSERT EMP VALUES(7900, 'JAMES','CLERK', 7698, 'DEC 03 1981',950,NULL,30)
INSERT EMP VALUES(7902, 'FORD','ANALYST',7566, 'DEC 03 1981',3000,NULL,20)

---DQL where,like,between,in,aggr func,orderby,group by

select * from emp
select EMPNO,ENAME,SAL DEPTNO from emp
select empno'EmployeeNo',ename'EmployeeName' from emp
--display name of column
select job from emp
select distinct(job) from emp
select * from emp  where job='clerk'

--- with where and logical operator
select * from emp  where job='clerk' and job='analyst' -- both values available in single row
select * from emp  where job='clerk' or job='analyst'
select * from emp  where job='clerk' and sal<1000

---relatonal operators
select * from emp  where sal>=1000 and sal<=2000
--relational can be replaced with between and not between
select * from emp  where sal between 1000 and 2000
select * from emp  where sal not between 1000 and 2000

--like (pattern matching operator)
-- �% -> retreive all name beginning with A ,%S -> end with S, A%S- > start with A and End with S , %a% -> value a can be anywhere in the name
-- _a% -> a should be second character in the pattern , _ is for 1 character , _ _ _ _ -> it should be 4 character length

select ename from emp where ename not like 'M%'
select ename from emp where ename like '%S'
select ename from emp where ename like 'A%S'
select ename from emp where ename like '_a%'
select ename from emp where ename like '%a%'
select ename from emp where ename not like '____'
select ename from emp where ename like '[A-D]%S'

---orderby
select ename from emp order by ename
select ename from emp order by ename desc
select ename,sal from emp order by sal


--group by and aggregate functions will work together
--aggr () count, min, max, sum and avg
--count, min,max can work on all datatype , sum() and avg() -> numerical datatype
--count(*) - count null and not null, count(colname)- count only not null values

select count(*)'Total Count',count(comm)'Total comm' from emp
select max(ename)'MAX NAME',min(ename)'MIN ENAME',max(sal) 'MAX SAL',min(sal)'MIN SAL',max(hiredate)'MAX DATE',min(hiredate)'MIN DATE' from emp

select sum(ename) from emp
select sum(sal)'sum sal',avg(sal)'avg sal' from emp

--group by ->select col, agg func from where group by order by
select count(*)'Total Emp' ,sum(sal)'Total sal' ,job from emp group by job

select count(*)'Total Emp' ,sum(sal)'Total sal' ,job from emp where job<>'PRESIDENT' group by job

select count(*)'Total Emp' ,sum(sal)'Total sal' ,job from emp where job<>'PRESIDENT' group by job
having count(*)>=3 

--joins
select * from emp,dept

insert into emp(empno,ename) values(1,'ABC'),(2,'XYZ')
insert into dept values(50,'SEMI CONDUCTOR','INDIA')

--inner join also called as equi join ->get matching data from both tables
--condition->primary key foreign key of both tables

select e.ename,d.dname,d.deptno from emp e join dept d on e.DEPTNO=d.deptno

--outer join
--emp    --dept
--right outer join->consider all data from right table
select e.ename,d.dname,d.deptno from emp e right outer join dept d on e.DEPTNO=d.deptno

--left outer join->consider all data from left table
select e.ename,d.dname,d.deptno from emp e left outer join dept d on e.DEPTNO=d.deptno

--full outer join->consider all data from both table, left outer+right outer=full outer
select e.ename,d.dname,d.deptno from emp e full outer join dept d on e.DEPTNO=d.deptno


--views temporary tables which will not have any own strucutre. structure is based on base table from which we get data
--views will not occupy memory
-- we can create complex queries and execute any number of times

create view view_fulljoin
as
select e.ename,d.dname,d.deptno from emp e full outer join dept d on e.DEPTNO=d.deptno

select * from view_fulljoin

create view view_dept20
as
select * from emp where deptno=20

select * from view_dept20
update view_dept20 set DEPTNO=50 where ENAME='ADAMS'

--- check updation of view
-- oncheck option

create view view_dept10
as
select * from emp where deptno=10 with check option

select * from view_dept10
update view_dept10 set DEPTNO=40 where ENAME='KING'-- can't change dept because check option is given for deptno

select * from view_dept10
update view_dept10 set ENAME='CEO' where ENAME='KING'

--- INDEX
--sql engine uses index for faster retrieval
--clustered index->created on primary index column
--one table can have only 1 clustered index

-- unique non clustered index-->created on unique constraint
--999 nonclustered index
create index ind_ename on emp(ename)