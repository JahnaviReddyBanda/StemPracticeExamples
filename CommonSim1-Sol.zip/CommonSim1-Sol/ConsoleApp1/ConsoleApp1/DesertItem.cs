﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DessertShop
{ 
    class DessertItem
    {
        string Name;

        public void getName()
        {
            Console.WriteLine("Name :" + Name);
        }
        public void setName()
        {
            Console.SetIn(Name);
        }
    }
    class Candy : DessertItem
    {
        double weight;
        double pricePerPound;
        double Cost;
        public Candy(double r, double h)
        {
            weight = r;
            pricePerPound = h;
        }
        public double Cost()
        {
            return (r * h);
        }
        public void DisplayCost()
        {
            Console.WriteLine("The Cost of Candy is "+ cost);
        }
    }
    class COC
    {
        static void Main()
        {
            Candy c1 = new Candy(2.30, 0.89);
            c1.getName();
            Console.WriteLine("Cost is " + c1.Cost());
        }
    }

    class Cookie : DessertItem
    {
        double itemCount;
        double pricePerDozen;
        double Cost;


        public Cookie(double r, double h)
        {
            itemCount = r;
            pricePerDozen = h;
        }
        public double cost()
        {
            return r * (h / 12);
        }
        public void DisplayCost()
        {
            Console.WriteLine("The Cost of Cookie is "
                                            + Cost);
        }
    }
    class COCook
    {
        static void Main()
        {
            Cookie c1 = new Cookie(4, 399);
            c1.getName();
            Console.WriteLine("Cost is " + c1.cost());
        }
    }
    class Icecream : DessertItem
    {
        int numberOfScoops;
        double pricePerScoop;
        double cost;
        double toppingPrice;
        public Icecream(int r, double h, double t)
        {
            numberOfScoops = r;
            pricePerScoop = h;
            toppingPrice = t;
        }
        public double Cost()
        {
            return ((r * h) + t);
        }
        public void DisplayCostIce()
        {
            Console.WriteLine("The Cost of Icecream is "+ cost);
        }
    }
    class COIce
    {
        static void Main()
        {
            Icecream c1 = new Icecream(1, 100, 10);
            c1.getName();
            Console.WriteLine("Cost is " + c1.Cost());
        }
    }
}