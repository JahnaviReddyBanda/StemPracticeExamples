﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class RegTableModel
    {
        public string Name { get; set; }
        public string Address { get; set; }

        public DateTime date { get; set; }
        public decimal phone { get; set; }
        public string size { get; set; }
        public string topping { get; set; }
        public int deliver { get; set; }
        public string special { get; set; }

    }
}