﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.Models;
using WebApplication1.DataAccessLayer;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        ListItem temp;
        RegTableModel model = new RegTableModel();
        RegTableDB db = new RegTableDB();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void CheckBoxList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try { 
            DateTime date = DateTime.Parse(txtDate.Text);
            string name = txtName.Text;
            decimal phone = decimal.Parse(txtPhone.Text);
            string address = txtAddress.Text;
            int pin = int.Parse(txtPin.Text);
            string size = "";
            string topping = "";
            if (rdoSmall.Checked)
            {
                size = "small";
            }
            if (rdoMedium.Checked)
            {
                size = "medium";
            }
            if (rdoLarge.Checked)
            {
                size = "large";
            }
            foreach (ListItem temp in chkTopping.Items)
            {
                if (temp.Selected)
                    topping += temp.Text + ",";
            }
            address += "," + pin.ToString();
            int deliver = 0;
            if (chkDeliver.Checked)
            {
                deliver = 1;
            }

            model.Address = address;
            model.date = date;
            model.Name = name;
            model.deliver = deliver;
            model.size = size;
            model.topping = topping;
                model.special = txtSpecial.Text;
            int res = db.InsertRegTable(model);

            if (res > 0)
            {
                Output.Text = "success";
            }
        }
            catch (Exception ex) {
                Output.Text = ex.Message;
            }
        }

        protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}