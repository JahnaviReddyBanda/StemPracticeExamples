﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using WebApplication1.Models;

namespace WebApplication1.DataAccessLayer
{
    public class RegTableDB
    {
        string connstr = "Data Source = (localdb)\\MSSQLLocalDB;Initial Catalog = CommonSimulation1; Integrated Security = True";
        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader r = null;
        SqlDataAdapter adp = null;
        DataSet ds = null;

        public int InsertRegTable(RegTableModel model)
        {
            try
            {
                con = new SqlConnection(connstr);
                con.Open();
                string query = "insert into customer values(@nm,@add)";
                cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nm", model.Name);
                cmd.Parameters.AddWithValue("@add", model.Address);
                int res = cmd.ExecuteNonQuery();
            }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }

            try
            {
                con = new SqlConnection(connstr);
                con.Open();
                string query = "insert into pizzainfo values(@nm,@add,@siz,@top,@del,@spe)";
                cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@nm", model.date);
                cmd.Parameters.AddWithValue("@add", model.phone);
                cmd.Parameters.AddWithValue("@siz", model.size);
                cmd.Parameters.AddWithValue("@top", model.topping);
                cmd.Parameters.AddWithValue("@del", model.deliver);
                cmd.Parameters.AddWithValue("@spe", model.special);
                int res = cmd.ExecuteNonQuery();
                if (res > 0)
                    return 1;

            }
            catch (SqlException sql)
            {
                throw sql;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return 0;
        }

    }
}