create database commonSimulation1
use commonSimulation1
create table customer(cid int constraint pk_cid primary key identity(1,1),cname varchar(30),caddress varchar(50))

insert into customer values('name','klm')

select* from customer

create table pizzainfo(oid int constraint pk_oid primary key identity(1,1),orderdate date ,phoneno bigint,size varchar(10),
topping varchar(max),deliver bit ,special_info varchar(max));

select * from pizzainfo