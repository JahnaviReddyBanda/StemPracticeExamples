﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BankingProject.Models;
using BankingProject.DataAccessLayer;
namespace BankingProject
{
    public partial class NewAccounts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["cid"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                txtcid.Text = Session["cid"].ToString();
            }
        }

        protected void btnAccount_Click(object sender, EventArgs e)
        {

            try
            {
                AccountsModel am = new AccountsModel();
                am.CustId = int.Parse(txtcid.Text);
                am.AccountType = DropDownList1.SelectedItem.Text;
                if (rbActive.Checked)
                    am.Status = rbActive.Text;
                if(rbInactive.Checked)
                    am.Status=rbInactive.Text;

                BankingDB db = new BankingDB();
                var res = db.InsertAccounts(am);
                if (res > 0)
                    output.Text = "New Account Created. Account Id is:" + res;

            }
            catch(Exception ex)
            {
                output.Text = ex.Message;
            }
        }
    }
}