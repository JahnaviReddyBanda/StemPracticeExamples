create database StemDB

use StemDB

--create a table
create table RegTable
(Name varchar(35) not null,
Address varchar(100) not null,
Password varchar(20) not null,
Gender varchar(10),
Qualification varchar(30),
City varchar(30) not null,
Skills varchar(50),
age int,
email varchar(50) primary key)

-- insert data into table
insert into RegTable values('Martin','Mangalore','123','Male','BE,MBA','Bangalore','HTML,CSS,Angular','35','martin@gmail.com')

Select * from RegTable

Update RegTable set age=40, Address='Kochi' where email='martin@gmail.com'
Select * from RegTable