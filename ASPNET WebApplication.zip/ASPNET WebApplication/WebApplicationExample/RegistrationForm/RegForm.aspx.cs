﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RegistrationForm.Models;
using RegistrationForm.DataAccessLayer;

namespace RegistrationForm
{
    public partial class RegForm : System.Web.UI.Page
    {
        RegTableModel model = new RegTableModel();
        RegTableDB db = new RegTableDB();
        

        //string gender = "";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {

            model.Gender = rbmale.Text;
        }

        protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
        {
            model.Gender = rbfemale.Text;
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        

        protected void Button2_Click(object sender, EventArgs e)
        {
            model.Name = txtname.Text;
            model.Address = txtadd.Text;
            model.Password = txtpwd.Text;
            if (rbmale.Checked)
                model.Gender = rbmale.Text;
            if (rbfemale.Checked)
                model.Gender = rbfemale.Text;
            string q = "";
            foreach(ListItem t in cbqualification.Items)
            {
                if (t.Selected)
                    q += t.Text + ",";
            }
            model.City = ddlcity.SelectedItem.Text;
           // string sk = "";
            foreach(ListItem temp in sk.Items)
            {
                if (temp.Selected)
                    model.Skillsets += temp.Text + ",";
            }
            model.Age = int.Parse(txtage.Text);
            model.email = txtemail.Text;
            output.Text = model.Name + "," + model.Address + "," + model.Password + "," + model.Gender + "," + q + "," + model.City + "," + sk;
        }

        protected void CheckBoxList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            try
            {
                var result = db.SelectData();
                GridView1.DataSource = result;
                GridView1.DataBind();
            }
            catch(Exception ex)
            {
                output.Text = ex.Message;
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            try
            {
                var res = db.SelectDisconnected();
                GridView2.DataSource = res.Tables["RegTable"];
                GridView2.DataBind();

            }
            catch(Exception ex)
            {
                output.Text = ex.Message;
            }
        }

        protected void txtage_TextChanged(object sender, EventArgs e)
        {

        }
    }
}