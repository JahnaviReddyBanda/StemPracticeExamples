﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RegistrationForm
{
    public partial class Assignment : System.Web.UI.Page
    {
        double gs, ns;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }
        
        protected void Button1_Click(object sender, EventArgs e)
        {
            double bs = double.Parse(txtbs.Text);
            double da = double.Parse(txtda.Text);
            double hra = double.Parse(txthra.Text);
            double ca = double.Parse(txtca.Text);
            double ea = double.Parse(txtea.Text);
            double mi = double.Parse(txtmi.Text);
            double it = double.Parse(txtit.Text);
            double pf = double.Parse(txtpf.Text);
            gs = (bs + da + hra + ca + ea + mi + it + pf);
            ns = (gs - (it + pf));
            Txtgs.Text = gs.ToString();
            txtns.Text = ns.ToString();



        }

        protected void txtns_TextChanged(object sender, EventArgs e)
        {
            //output.Text = ns.ToString();

        }

        protected void Txtgs_TextChanged(object sender, EventArgs e)
        {
          //  output.Text = gs.ToString();

        }
    }
}