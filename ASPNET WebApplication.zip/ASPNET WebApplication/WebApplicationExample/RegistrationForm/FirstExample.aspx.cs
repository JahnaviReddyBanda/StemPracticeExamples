﻿using System;

namespace RegistrationForm
{
    public partial class FirstExample : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Write("My first ASP.NET Example");

        }
    }
}