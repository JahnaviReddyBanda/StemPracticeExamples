﻿namespace RegistrationForm
{
    internal class output
    {
        public static string Text { get; internal set; }
    }
}