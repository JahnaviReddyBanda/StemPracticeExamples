import {TestExample} from './getData';

var obj=new TestExample();
obj.str="Declared in getData and showing this variable in showData";
console.log(obj.str);