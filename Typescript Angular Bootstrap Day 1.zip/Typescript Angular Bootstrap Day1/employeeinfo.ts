class employeeinfo{
    private empid:number;
    private empname:string;
    private dept:string;
    private dsgn:string;
    private salary:number;

    getData():void{
        this.empid=100;
        this.empname="martin";
        this.dept="IT";
        this.dsgn="PM";
        this.salary=200000;

    }
    showData():void{
        console.log("EmpID:"+this.empid);
        console.log("EmpName"+this.empname);
        console.log("Dept:"+this.dept);
        console.log("Designation:"+this.dsgn);
        console.log("SalaryD:"+this.salary);
    }
    /*
    constructor(){
        this.empid=100000;
        this.empname="default";
        this.dept="default";
        this.dsgn="default";
        this.salary=200000;
    }*/
    constructor(eid:number,name:string,dep:string,des:string,sal:number){
        this.empid=eid;
        this.empname=name;
        this.dept=dep;
        this.dsgn=des;
        this.salary=sal;
    }
}
/*var martin=new employeeinfo();
martin.getData();
martin.showData();*/
var blake =new employeeinfo(345,"joe","tax","manager",546720);
blake.showData();
