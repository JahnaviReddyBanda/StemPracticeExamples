var employeeinfo = /** @class */ (function () {
    /*
    constructor(){
        this.empid=100000;
        this.empname="default";
        this.dept="default";
        this.dsgn="default";
        this.salary=200000;
    }*/
    function employeeinfo(eid, name, dep, des, sal) {
        this.empid = eid;
        this.empname = name;
        this.dept = dep;
        this.dsgn = des;
        this.salary = sal;
    }
    employeeinfo.prototype.getData = function () {
        this.empid = 100;
        this.empname = "martin";
        this.dept = "IT";
        this.dsgn = "PM";
        this.salary = 200000;
    };
    employeeinfo.prototype.showData = function () {
        console.log("EmpID:" + this.empid);
        console.log("EmpName" + this.empname);
        console.log("Dept:" + this.dept);
        console.log("Designation:" + this.dsgn);
        console.log("SalaryD:" + this.salary);
    };
    return employeeinfo;
}());
/*var martin=new employeeinfo();
martin.getData();
martin.showData();*/
var blake = new employeeinfo(345, "joe", "tax", "manager", 546720);
blake.showData();
