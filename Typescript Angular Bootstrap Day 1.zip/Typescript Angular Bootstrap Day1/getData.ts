export class TestExample{
    public str:string;
}