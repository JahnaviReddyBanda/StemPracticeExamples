interface IPerson
{
    firstname:string,
    lastname:string,
    age:number,
    sayHi:()=>string
}

var customer:IPerson=
{
    firstname:"Tom",
    lastname:"Jerry",
    age:17,
    sayHi:():string=>{
        return("Hi I am Tom and Jerry");
    }

}
var employee:IPerson={
    firstname:"scott",
    lastname:"tiger",
    age:18,
    sayHi:():string=>{
        return("Hi I am Scott and tiger");
    }

}
console.log("Customer Object");
console.log(customer.firstname);
console.log(customer.lastname);
console.log(customer.age);
console.log(customer.sayHi());

console.log("Employee Object");
console.log(employee.firstname);
console.log(employee.lastname);
console.log(employee.age);
console.log(employee.sayHi());
