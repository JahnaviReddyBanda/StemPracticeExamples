/*{
    return(fname);
    }
*/
function Add(p1, p2) {
    return (p1 + p2);
}
console.log("Addition:" + Add(12, 13));
console.log("Full Name:" + Add("Mickey", "Mouse"));
