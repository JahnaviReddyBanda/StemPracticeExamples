var customer = {
    firstname: "Tom",
    lastname: "Jerry",
    age: 17,
    sayHi: function () {
        return ("Hi I am Tom and Jerry");
    }
};
var employee = {
    firstname: "scott",
    lastname: "tiger",
    age: 18,
    sayHi: function () {
        return ("Hi I am Scott and tiger");
    }
};
console.log("Customer Object");
console.log(customer.firstname);
console.log(customer.lastname);
console.log(customer.age);
console.log(customer.sayHi());
console.log("Employee Object");
console.log(employee.firstname);
console.log(employee.lastname);
console.log(employee.age);
console.log(employee.sayHi());
