function Add(x:number,y:number):number
/*{ 
    return(x+y);
}*/
function Add(fname:string,lname:string):string
/*{ 
    return(fname);
    }
*/
function Add(p1:any,p2:any):any
{ 
    return(p1+p2);
}  
console.log("Addition:"+Add(12,13));
console.log("Full Name:"+Add("Mickey","Mouse"));