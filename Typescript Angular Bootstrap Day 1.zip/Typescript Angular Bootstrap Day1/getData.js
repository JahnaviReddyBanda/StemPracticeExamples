"use strict";
exports.__esModule = true;
exports.TestExample = void 0;
var TestExample = /** @class */ (function () {
    function TestExample() {
    }
    return TestExample;
}());
exports.TestExample = TestExample;
