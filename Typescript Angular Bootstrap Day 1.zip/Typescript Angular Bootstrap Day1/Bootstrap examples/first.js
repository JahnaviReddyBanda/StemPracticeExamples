console.log("My first typescript program");
