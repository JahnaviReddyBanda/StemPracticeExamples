"use strict";
exports.__esModule = true;
var getData_1 = require("./getData");
var obj = new getData_1.TestExample();
obj.str = "Declared in getData and showing this variable in showData";
console.log(obj.str);
