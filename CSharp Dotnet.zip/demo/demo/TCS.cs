﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace demo
{
    public class TCS:EmployeeInfo,GovtRules
    {
        int empid;
        string name;
        string dept;
        string desg;
        double salary;
        int service;
        double gAmt=0;
        public override void GetData()
        {
            base.GetData();
            Console.WriteLine("Enter empid:");
            empid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter dept:");
            dept = Console.ReadLine();
            Console.WriteLine("Enter desg:");
            desg = Console.ReadLine();
            Console.WriteLine("Enter salary:");
            salary = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter no of service year:");
            service=int.Parse(Console.ReadLine())

        }
        public override void showData()
        {
            base.showData();
            Console.WriteLine("Empid:" + empid);
            Console.WriteLine("Dept:" + dept);
            Console.WriteLine("Designation:" + desg);
            Console.WriteLine("Salary:" + salary);
        }
        public double EmployeePF(double basicSalary)
        {
            this.salary=basicSalary;
            double pf=salary*0.12;
            double ec=salary*0.0833;
            
        }
        public void gratuityAmt(int service,double basicSalary)
        {
            if(service>5)
                gAmt=basicSalary;
            else if(service>10)
                gAmt=basicSalary*2;
            else if(service>20)
                gAmt=basicSalary*3;
            else if(service<5)
                gAmt=0;
        }
    }
}
