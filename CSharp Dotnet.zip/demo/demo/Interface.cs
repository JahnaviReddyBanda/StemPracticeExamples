﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace demo
{
    interface GovtRules
    {
        public double EmployeePF(double basicSalary);
        public string LeaVeDetails();
        public double gratuityAmount(float serviceCompleted, double basicSalary);
    }
}