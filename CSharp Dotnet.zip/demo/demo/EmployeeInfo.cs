﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace demo
{
    public class EmployeeInfo
    {
        int empid;
        string name;
        string dept;
        string desg;
        double salary;
        public void GetData()
        {
            
            Console.WriteLine("Enter empid:");
            empid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter dept:");
            dept = Console.ReadLine();
            Console.WriteLine("Enter desg:");
            desg = Console.ReadLine();
            Console.WriteLine("Enter salary:");
            salary = double.Parse(Console.ReadLine());

        }
        public void showData()
        {
            
            Console.WriteLine("Empid:" + empid);
            Console.WriteLine("Dept:" + dept);
            Console.WriteLine("Designation:" + desg);
            Console.WriteLine("Salary:" + salary);
            }
        
        public EmployeeInfo(string name,char gen,int age,int empid,string dept,string desg,double sal)
        {
            this.empid = empid;
            this.dept = dept;
            this.desg = desg;
            this.salary = sal;
        }

    }
}