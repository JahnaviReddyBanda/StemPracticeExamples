﻿use stemDB

create table Login
(email varchar(100) constraint pk_email primary key,
password varchar(10) not null)

insert into Login values('Joe@gmail.com','abc@123')

insert into Login values('Bin@gmail.com','123')
Select * from Login

create table Reunion
(MembershipId int constraint pk_MemId primary key identity,
Attendance varchar(5) not null,
FirstName varchar(50) not null,
LastName varchar(50) not null,
PhoneNumber bigint not null,
Meals varchar(50) not null,
Games varchar(max) not null,
Questions varchar(max) not null)

create proc sp_InsertReunion(@attn varchar(5),@fn varchar(50),@ln varchar(50),@pn bigint,@meals varchar(50),
@games varchar(max),@ques varchar(max),@memid int out)
as
begin
insert into Reunion values(@attn,@fn,@ln,@pn,@meals,@games,@ques)
select @memid=@@IDENTITY
end

create proc sp_SelectReunion
as
begin
Select * from Reunion
end

declare @memid int

execute sp_InsertReunion'Yes','Priya','Kumar','8989768993','NonVegeterian','Indoor,Outdoor','If there is no rain,I will join',@memid out
print'My membership id is:'+convert(varchar(4),@memid)

exec sp_SelectReunion

create table student
(StudentId int constraint pk_StudId primary key,
FirstName varchar(50) not null,
LastName varchar(50) not null,
Marketing int not null,
Accounting int not null,
Computing int not null,
Total int not null,
Grade varchar(2) not null)

create proc sp_InsertMarks(@stdid int,@fn varchar(50),@ln varchar(50),@marketing int,@accounting int,
@computing int,@total int out,@grade int out)
as
begin
insert into Reunion values(@stdid,@fn,@ln,@marketing,@accounting,@computing)
select @memid=@@IDENTITY
end