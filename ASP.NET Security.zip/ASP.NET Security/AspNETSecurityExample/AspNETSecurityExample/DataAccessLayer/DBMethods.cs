﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using AspNETSecurityExample.Models;
namespace AspNETSecurityExample.DataAccessLayer
{
    public class DBMethods
    {
        string connect = "Data Source=(localdb)\\MSSqlLocalDB;Initial Catalog=StemDB;Integrated Security=True;";
        SqlConnection con = null;
        SqlCommand comm = null;
        SqlDataReader r = null;

        public bool Login(string email,string password)
        {
            try
            {
                con = new SqlConnection(connect);
                con.Open();
                string query = "select * from Login where email=@em and password=@pwd";
                comm = new SqlCommand(query, con);
                comm.Parameters.AddWithValue("@em", email);
                comm.Parameters.AddWithValue("@pwd", password);
                r = comm.ExecuteReader();
                if (r.Read())
                    return true;
            }
            catch {
                throw;
            }
            finally
            {
                con.Close();
            }
            return false;
        }
        public int InsertReunion(ReunionModel model)
        {
            try
            {
                con = new SqlConnection(connect);
                con.Open();
                comm = new SqlCommand("sp_InsertReunion", con);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@attn", model.Attendance);
                comm.Parameters.AddWithValue("@fn", model.FirstName);
                comm.Parameters.AddWithValue("@ln", model.LastName);
                comm.Parameters.AddWithValue("@pn", model.PhoneNo);
                comm.Parameters.AddWithValue("@meals", model.Meals);
                comm.Parameters.AddWithValue("@games", model.Games);
                comm.Parameters.AddWithValue("@ques", model.Questions);
                SqlParameter memid = new SqlParameter("@memid", SqlDbType.Int);
                memid.Direction = ParameterDirection.Output;
                comm.Parameters.Add(memid);
                var res = comm.ExecuteNonQuery();
                if (res == 1)
                    return (int)memid.Value;

            }
            catch{
                throw;
            }
            finally
            {
                con.Close();
            }
            return 0;
        }
        public List<ReunionModel> SelectReunion()
        {
            List<ReunionModel> data = new List<ReunionModel>();
            try
            {
                con = new SqlConnection(connect);
                con.Open();
                comm = new SqlCommand("sp_SelectReunion", con);
                comm.CommandType = CommandType.StoredProcedure;
                var r = comm.ExecuteReader();
                while(r.Read())
                {
                    ReunionModel m = new ReunionModel();
                    m.MemID=(int)r[0];
                    m.Attendance = r[1].ToString();
                    m.FirstName = r[2].ToString();
                    m.LastName = r[3].ToString();
                    m.PhoneNo = (long)r[4];
                    m.Meals = r[5].ToString();
                    m.Games = r[6].ToString();
                    m.Questions = r[7].ToString();
                    data.Add(m);

                }

            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return data;
        }


    }
}