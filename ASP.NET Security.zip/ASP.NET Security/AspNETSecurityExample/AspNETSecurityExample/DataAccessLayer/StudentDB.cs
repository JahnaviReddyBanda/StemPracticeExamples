﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AspNETSecurityExample.DataAccessLayer
{
    public class StudentDB
    {
        string connect = "Data Source=(localdb)\\MSSqlLocalDB;Initial Catalog=StemDB;Integrated Security=True;";
        SqlConnection con = null;
        SqlCommand comm = null;
        SqlDataReader r = null;
        public int InsertMarks(StudentModel model)
        {
            try
            {
                con = new SqlConnection(connect);
                con.Open();
                comm = new SqlCommand("sp_InsertReunion", con);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@attn", model.Attendance);
                comm.Parameters.AddWithValue("@fn", model.FirstName);
                comm.Parameters.AddWithValue("@ln", model.LastName);
                comm.Parameters.AddWithValue("@pn", model.PhoneNo);
                comm.Parameters.AddWithValue("@meals", model.Meals);
                comm.Parameters.AddWithValue("@games", model.Games);
                comm.Parameters.AddWithValue("@ques", model.Questions);
                SqlParameter memid = new SqlParameter("@memid", SqlDbType.Int);
                memid.Direction = ParameterDirection.Output;
                comm.Parameters.Add(memid);
                var res = comm.ExecuteNonQuery();
                if (res == 1)
                    return (int)memid.Value;

            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return 0;
        }
    }
}