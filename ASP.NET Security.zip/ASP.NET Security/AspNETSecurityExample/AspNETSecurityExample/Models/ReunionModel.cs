﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AspNETSecurityExample.Models
{
    public class ReunionModel
    {
        public int MemID { get; set; }
        public string Attendance { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public long PhoneNo { get; set; }
        public string Meals { get; set; }
        public string Games { get; set; }
        public string Questions{ get; set; }

    }
}