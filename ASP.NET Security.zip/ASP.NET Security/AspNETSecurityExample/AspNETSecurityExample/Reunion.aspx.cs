﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AspNETSecurityExample.DataAccessLayer;
using AspNETSecurityExample.Models;

namespace AspNETSecurityExample
{
    public partial class Reunion : System.Web.UI.Page
    {
        ReunionModel model = new ReunionModel();    
        //RegTableDB db = new RegTableDB();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
         
        
            if (Yes.Checked)
                model.Attendance= Yes.Text;
            if (No.Checked)
                model.Attendance = No.Text;
            model.FirstName = firstname.Text;
            model.LastName = lastname.Text;
            model.PhoneNo = long.Parse(phoneno.Text);
            if (Vegetarian.Checked)
                model.Meals = Vegetarian.Text;
            if (NonVegetarian.Checked)
                model.Meals = NonVegetarian.Text;
            foreach(ListItem li in cbgames.Items)
            {
                if (li.Selected)
                    model.Games += li.Text + ",";
            }
            model.Questions = questions.Text;
            Output.Text = model.Attendance + "," + model.FirstName + "," + model.LastName + "," + model.PhoneNo + "," + model.Meals + ","
                + model.Games + "," + model.Questions;
            try
            {
                DBMethods db = new DBMethods();
                var res = db.InsertReunion(model);
                if(res>0)
                    Output.Text="Thanks for Response Membership id is:"+res;
            }
            catch(Exception ex)
            {
                Output.Text = ex.Message;
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                DBMethods db = new DBMethods();
                var res = db.SelectReunion();
                GridView1.DataSource = res;
                GridView1.DataBind();
            }
            catch(Exception ex)
            {
                Output.Text = ex.Message;
            }
        }

        
    }
}