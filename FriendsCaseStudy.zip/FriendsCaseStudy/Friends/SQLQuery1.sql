﻿create database FriendCaseStudy

use FriendCaseStudy


create table Friend
(FriendId int constraint pk_friendid primary key , FriendName varchar(30) not null, Place varchar(30) not null)

select * from Friend

--contributed by Aditya
create procedure sp_InsertFriend(@friendid int, @name varchar(30),@place varchar(30))
as 
begin insert into Friend values(@friendid,@name,@place)
end

--contributed by Hafeeza
create procedure sp_UpdateFriend(@friendid int, @name varchar(30),@place varchar(30))
as
begin
delete from Friend where FriendId=@friendid 
insert into Friend values(@friendid,@name,@place)
end

--contributed by Jahnavi
create procedure sp_DeleteFriend(@friendid int)
as
begin 
delete from Friend where FriendId=@friendid
end
