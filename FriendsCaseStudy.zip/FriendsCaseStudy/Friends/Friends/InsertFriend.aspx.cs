﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Friends.Models;
using Friends.DataAccessLayer;

namespace Friends
{
    public partial class InsertFriend : System.Web.UI.Page
    {
        //contributed by Aditya
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {
                FriendDB db = new FriendDB();
                Friend m = new Friend();
                m.FriendId = int.Parse(txtfid.Text);
                m.FriendName = txtfname.Text;
                m.Place = txtplace.Text;
                output.Text = "Data Inserted Successfully!";
                var res = db.InsertFriend(m);


            }
            catch (Exception ex)
            {
                output.Text = ex.Message;
            }

        }

        protected void btnback_Click(object sender, EventArgs e)
        {

            Response.Redirect("HomePage.aspx");
        }
    }
}