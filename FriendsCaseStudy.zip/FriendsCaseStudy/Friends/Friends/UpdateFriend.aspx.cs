﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Friends.Models;
using Friends.DataAccessLayer;

namespace Friends
{
    public partial class UpdateFriend : System.Web.UI.Page
    {
        //contributed by Hafeeza
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["friendid"] == null)
                Response.Redirect("InsertFriend.aspx");
            else
                txtfid.Text = Session["friendid"].ToString();
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                FriendDB db = new FriendDB();
                Friend m = new Friend();
                m.FriendId = int.Parse(txtfid.Text);
                m.FriendName = txtfname.Text;
                m.Place = txtplace.Text;
                output.Text = "Data Updated Successfully!";
                var res = db.UpdateFriend(m);


            }
            catch (Exception ex)
            {
                output.Text = ex.Message;
            }
        }

        protected void btnback_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }
    }
}