﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Friends.Models;
using System.Diagnostics.PerformanceData;

namespace Friends.DataAccessLayer
{
    public class FriendDB
    {
        //contributed by Jahnavi

        string connect = "Data Source=(localdb)\\MSSqlLocalDB;Initial Catalog=FriendCaseStudy;Integrated Security=true;";

        SqlConnection con = null;
        SqlCommand cmd = null;
        SqlDataReader r = null;
        public int InsertFriend(Friend f) 
        {
            try
            {
                con = new SqlConnection(connect);
                con.Open();
                cmd = new SqlCommand("sp_InsertFriend", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@friendid", f.FriendId);
                cmd.Parameters.AddWithValue("@name", f.FriendName);
                cmd.Parameters.AddWithValue("@place", f.Place);
                var res = cmd.ExecuteNonQuery();

            }
            catch
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            return 0;
        }

        public string UpdateFriend(Friend f)
        {
            try
            {
                con = new SqlConnection(connect);
                con.Open();
                cmd = new SqlCommand("sp_UpdateFriend", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@friendid", f.FriendId);
                cmd.Parameters.AddWithValue("@name", f.FriendName);
                cmd.Parameters.AddWithValue("@place", f.Place);

                var res = cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return "";
        }

        public string DeleteFriend(int FriendId)
        {
            try
            {
                con = new SqlConnection(connect);
                con.Open();
                cmd = new SqlCommand("sp_DeleteFriend", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@friendid", FriendId);
                //cmd.Parameters.AddWithValue("@name", f.FriendName);
                // cmd.Parameters.AddWithValue("@place", f.Place);
                var res = cmd.ExecuteNonQuery();


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return "";
        }

    }
}