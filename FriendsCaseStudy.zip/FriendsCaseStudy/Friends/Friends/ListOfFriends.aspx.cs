﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Friends.Models;
using Friends.DataAccessLayer;
namespace Friends
{
    public partial class ListOfFriends : System.Web.UI.Page
    {

        //contributed by Hafeeza
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btnback_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");

        }

        protected void edit_Click1(object sender, EventArgs e)
        {

            Button btn = (Button)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            Session["friendid"] = row.Cells[0].Text;
            // int r = int.Parse(row.Cells[0].Text);
            Response.Redirect("UpdateFriend.aspx");

            try
            {
                FriendDB db = new FriendDB();
                Friend m = new Friend();

                var res = db.UpdateFriend(m);
                GridView1.DataBind();


            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected void delete_Click1(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            GridViewRow row = (GridViewRow)btn.NamingContainer;
            //Session["friendid"] = row.Cells[0].Text;
            int r = int.Parse(row.Cells[0].Text);


            try
            {
                FriendDB db = new FriendDB();
                Friend m = new Friend();

                var res = db.DeleteFriend(r);
                GridView1.DataBind();


            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}